from django.shortcuts import render, redirect , HttpResponse
from django.contrib.auth.forms import UserCreationForm
# from .forms import CreateUserForm
from django.contrib.auth import login, authenticate, logout
# from django.urls import HTTPResponse

def home(request):
    return render(request, 'home.html')
def contact(request):
    return render(request, 'contact.html')
def about(request):
    return render(request, 'about.html')
def index(request):
    return render(request, 'index.html')
def inquiries(request):
    return render(request, 'inquiries.html')
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Correct the authenticate call:
        user = authenticate(username=username, password=password) 

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password'})

    return render(request, 'login.html')
def signup_view(request):
    # return render(request, 'signup.html')
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
    context = {'form': form}
    return render(request, "signup.html", context)
def signin(request):
    if request.method == 'POST':
        username = request.POST.get('login-username')
        password = request.POST.get('login-password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('index')
        # else:
        #     messages.info(request, 'Username or Password is incorrect')
    
    context = {}
    return render(request, 'login.html', context)

def index(request):
    return render(request, "index.html")