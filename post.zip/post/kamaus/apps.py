from django.apps import AppConfig


class KamausConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kamaus'
